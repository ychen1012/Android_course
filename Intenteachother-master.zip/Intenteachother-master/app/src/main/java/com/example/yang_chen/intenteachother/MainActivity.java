package com.example.yang_chen.intenteachother;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);
        Button next =(Button)findViewById(R.id.next);





        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edit =(EditText) findViewById(R.id.edit);
                String data =edit.getText().toString();
                Intent intent =new Intent(MainActivity.this,Second.class);
                intent.putExtra("data", data );

                startActivity(intent);
            }
        });

        Intent intent=getIntent();
        String data =intent.getStringExtra("data");
        Toast.makeText(MainActivity.this,data,Toast.LENGTH_LONG).show();

    }
}
